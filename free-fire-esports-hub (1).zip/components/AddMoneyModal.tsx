import React, { useState, useEffect } from 'react';
import { PaymentGateway } from '../types';
import { KeyIcon, PhoneIcon } from './icons/Icons';
import { useLanguage } from '../context/LanguageContext';

interface AddMoneyModalProps {
    isOpen: boolean;
    onClose: () => void;
    gateway: PaymentGateway;
    onSubmit: (amount: number) => void;
}

type PaymentStep = 'enterAmount' | 'confirmPayment' | 'enterBkashNumber' | 'enterOtp' | 'enterPin' | 'processing';

const AddMoneyModal: React.FC<AddMoneyModalProps> = ({ isOpen, onClose, gateway, onSubmit }) => {
    const { t } = useLanguage();
    const [amount, setAmount] = useState<number | ''>('');
    const [error, setError] = useState('');
    const [step, setStep] = useState<PaymentStep>('enterAmount');

    // State for bKash flow
    const [bkashNumber, setBkashNumber] = useState('');
    const [otp, setOtp] = useState('');
    const [pin, setPin] = useState('');
    const [simulatedOtp, setSimulatedOtp] = useState('');

    useEffect(() => {
        if (isOpen) {
            setAmount('');
            setError('');
            setStep('enterAmount');
            setBkashNumber('');
            setOtp('');
            setPin('');
            setSimulatedOtp('');
        }
    }, [isOpen]);

    const handleAmountSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (typeof amount === 'number' && amount > 0) {
            setError('');
            if (gateway.name === 'bKash') {
                setStep('enterBkashNumber');
            } else {
                setStep('confirmPayment');
            }
        } else {
            setError('Please enter a valid amount.');
        }
    };
    
    const handleBkashNumberSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const generatedOtp = Math.floor(100000 + Math.random() * 900000).toString();
        setSimulatedOtp(generatedOtp);
        setStep('enterOtp');
    };

    const handleOtpSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (otp === simulatedOtp) {
            setError('');
            setStep('enterPin');
        } else {
            setError('Invalid OTP. Please try again.');
        }
    };

    const handlePinSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (pin.length >= 4) {
             setError('');
             handleConfirmPayment();
        } else {
            setError('PIN must be at least 4 digits.');
        }
    };

    const handleConfirmPayment = () => {
        setStep('processing');
        setTimeout(() => {
            if (typeof amount === 'number') {
                onSubmit(amount);
            }
            onClose();
        }, 2000);
    };

    const handleClose = () => {
        onClose();
    };
    
    const BkashHeader = () => (
        <div className="bg-[#e2136e] p-3 text-white text-center rounded-t-lg">
             <img src="https://seeklogo.com/images/B/bkash-logo-FBB25873C6-seeklogo.com.png" alt="bKash Logo" className="h-6 mx-auto" />
             <p className="text-sm mt-2">Merchant: {t('appName')}</p>
             <p className="font-bold text-lg">Invoice: FF-{Date.now()}</p>
             <p className="font-bold text-2xl">৳{amount}</p>
        </div>
    );

    const renderContent = () => {
        switch (step) {
            case 'enterAmount':
                return (
                    <form onSubmit={handleAmountSubmit} className="p-6 font-body">
                        <h2 id="add-money-title" className="text-2xl font-heading font-bold text-center text-primary mb-2">
                            {t('depositVia', { gatewayName: gateway.name })}
                        </h2>
                        <p className="text-center text-text-secondary mb-6">{t('enterAmount')}</p>
                        <div className="space-y-4">
                            <div>
                                <label htmlFor="amount" className="block text-sm font-medium text-text-secondary">{t('amountBdt')}</label>
                                <input type="number" id="amount" value={amount}
                                    onChange={(e) => {
                                        setAmount(e.target.value === '' ? '' : parseInt(e.target.value));
                                        setError('');
                                    }}
                                    required placeholder="e.g., 500" autoFocus
                                    className="mt-1 block w-full bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md py-3 px-4 text-text-primary text-lg text-center font-bold focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary" />
                                {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
                            </div>
                        </div>
                        <div className="mt-8">
                            <button type="submit" className="w-full py-3 px-4 rounded-md font-bold text-white bg-primary hover:bg-primary/80 transition-colors transform hover:scale-105">
                                {t('proceedToPay')}
                            </button>
                        </div>
                    </form>
                );
            
            case 'enterBkashNumber':
                return (
                    <div>
                        <BkashHeader />
                        <form onSubmit={handleBkashNumberSubmit} className="p-6 font-body">
                            <label htmlFor="bkashNumber" className="block text-sm font-medium text-text-secondary">{t('yourBkashAccount')}</label>
                            <div className="relative mt-1">
                                <PhoneIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                                <input type="tel" id="bkashNumber" value={bkashNumber} onChange={e => setBkashNumber(e.target.value)} required autoFocus
                                    className="w-full bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md py-3 pr-3 pl-10 text-text-primary" />
                            </div>
                            <button type="submit" className="mt-4 w-full py-2.5 rounded-md font-semibold text-white bg-[#e2136e] hover:bg-[#c0105c]">{t('confirm')}</button>
                            <button type="button" onClick={handleClose} className="mt-2 w-full py-2 rounded-md font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700">{t('cancel')}</button>
                        </form>
                    </div>
                );
            
            case 'enterOtp':
                return (
                    <div>
                        <BkashHeader />
                        <form onSubmit={handleOtpSubmit} className="p-6 font-body">
                            <p className="text-sm text-center text-text-secondary">{t('otpSent', { bkashNumber })}</p>
                            <p className="text-center font-bold text-blue-500 mt-1 mb-3">{t('demoOtp', { simulatedOtp })}</p>
                            <label htmlFor="otp" className="block text-sm font-medium text-text-secondary">{t('enterVerificationCode')}</label>
                            <input type="number" id="otp" value={otp} onChange={e => setOtp(e.target.value)} required autoFocus
                                className="mt-1 w-full text-center tracking-[1em] bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md py-3 px-3 text-text-primary" />
                            {error && <p className="text-red-500 text-xs mt-1 text-center">{error}</p>}
                            <button type="submit" className="mt-4 w-full py-2.5 rounded-md font-semibold text-white bg-[#e2136e] hover:bg-[#c0105c]">{t('confirm')}</button>
                            <button type="button" onClick={handleClose} className="mt-2 w-full py-2 rounded-md font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700">{t('cancel')}</button>
                        </form>
                    </div>
                );

            case 'enterPin':
                 return (
                    <div>
                        <BkashHeader />
                        <form onSubmit={handlePinSubmit} className="p-6 font-body">
                            <label htmlFor="pin" className="block text-sm font-medium text-center text-text-secondary">{t('enterPin')}</label>
                            <div className="relative mt-1">
                                <KeyIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                                <input type="password" id="pin" value={pin} onChange={e => setPin(e.target.value)} required autoFocus maxLength={5}
                                    className="w-full text-center tracking-[1em] bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md py-3 px-3 text-text-primary" />
                            </div>
                            {error && <p className="text-red-500 text-xs mt-1 text-center">{error}</p>}
                            <button type="submit" className="mt-4 w-full py-2.5 rounded-md font-semibold text-white bg-[#e2136e] hover:bg-[#c0105c]">{t('confirm')}</button>
                            <button type="button" onClick={handleClose} className="mt-2 w-full py-2 rounded-md font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700">{t('cancel')}</button>
                        </form>
                    </div>
                );

            case 'confirmPayment':
                return (
                    <div className="p-8 text-center font-body">
                        <img src={`https://logo.clearbit.com/${gateway.name.toLowerCase()}.com`} alt={`${gateway.name} logo`} className="h-10 w-auto mx-auto mb-4 grayscale" />
                        <h2 className="text-xl font-heading font-bold text-center text-primary">{t('confirmPayment')}</h2>
                        <p className="text-text-secondary mt-2">{t('aboutToPay')}</p>
                        <p className="text-4xl font-heading font-bold my-4 text-text-primary">৳{amount}</p>
                        <p className="text-text-secondary">{t('usingGateway', { gatewayName: gateway.name })}</p>
                        <div className="mt-8 flex flex-col space-y-3">
                            <button onClick={handleConfirmPayment} className="w-full py-3 px-4 rounded-md font-bold text-white bg-green-600 hover:bg-green-700">{t('confirmPayment')}</button>
                            <button onClick={handleClose} className="w-full py-2 px-4 rounded-md font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700">{t('cancel')}</button>
                        </div>
                    </div>
                );
            case 'processing':
                return (
                    <div className="p-8 text-center font-body">
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
                        <h2 className="text-xl font-heading font-bold text-center text-primary mt-4">{t('processingPayment')}</h2>
                        <p className="text-text-secondary mt-2">{t('processingPaymentDescription')}</p>
                    </div>
                );
        }
    };
    
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex justify-center items-center p-4" onClick={step !== 'processing' ? handleClose : undefined} role="dialog" aria-modal="true" aria-labelledby="add-money-title">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-sm" onClick={(e) => e.stopPropagation()}>
                {renderContent()}
            </div>
        </div>
    );
};

export default AddMoneyModal;
